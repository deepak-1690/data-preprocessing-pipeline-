"""
validate.py
===========
Structural and integrity validation utilities (Section 4.1 of the
strategy document). Validation acts as a gate: critical failures should
stop the pipeline before cleaning/transformation proceeds.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

import pandas as pd

logger = logging.getLogger(__name__)


@dataclass
class ValidationReport:
    checked_rows: int
    missing_summary: dict[str, float] = field(default_factory=dict)
    duplicate_rows: int = 0
    dtype_mismatches: dict[str, str] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)

    @property
    def has_critical_errors(self) -> bool:
        return len(self.errors) > 0


def validate_schema(
    df: pd.DataFrame,
    expected_columns: list[str] | None = None,
    expected_dtypes: dict[str, str] | None = None,
) -> ValidationReport:
    """
    Run structural validation checks:
      - expected column presence
      - dtype conformance
      - duplicate row detection
      - missingness summary
    """
    report = ValidationReport(checked_rows=len(df))

    if expected_columns:
        missing_cols = set(expected_columns) - set(df.columns)
        if missing_cols:
            report.errors.append(f"Missing expected columns: {sorted(missing_cols)}")

    if expected_dtypes:
        for col, expected in expected_dtypes.items():
            if col in df.columns and str(df[col].dtype) != expected:
                report.dtype_mismatches[col] = f"expected {expected}, got {df[col].dtype}"

    report.duplicate_rows = int(df.duplicated().sum())
    report.missing_summary = df.isnull().mean().round(4).to_dict()

    logger.info(
        "Validation complete: %d rows, %d duplicates, %d dtype mismatches, %d errors",
        report.checked_rows, report.duplicate_rows, len(report.dtype_mismatches), len(report.errors),
    )
    return report


def check_consistency(df: pd.DataFrame, rules: list[tuple[str, Any]]) -> list[str]:
    """
    Apply cross-field consistency rules. Each rule is (description, boolean_series)
    where the boolean series is True for VALID rows. Returns human-readable
    violations for any rule with failing rows.
    """
    violations = []
    for description, valid_mask in rules:
        n_bad = int((~valid_mask).sum())
        if n_bad > 0:
            violations.append(f"{description}: {n_bad} row(s) failed")
    return violations
