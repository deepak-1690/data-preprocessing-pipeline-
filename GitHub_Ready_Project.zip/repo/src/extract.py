"""
extract.py
==========
Data extraction utilities for the acquisition & preprocessing pipeline.

Supports three extraction mechanisms, as described in Section 3 of the
strategy document:
    1. Direct file download / bulk export
    2. REST API ingestion (with basic rate-limit handling)
    3. Web scraping (fallback only)
"""
from __future__ import annotations

import time
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional

import pandas as pd
import requests

logger = logging.getLogger(__name__)

RAW_DATA_DIR = Path("data/raw")


def _timestamped_path(prefix: str, ext: str = "csv") -> Path:
    """Build a timestamped, non-overwriting path under data/raw/."""
    RAW_DATA_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    return RAW_DATA_DIR / f"{prefix}_{ts}.{ext}"


def extract_from_file(url_or_path: str, prefix: str = "raw") -> pd.DataFrame:
    """
    Extract data from a direct file download or local bulk export
    (CSV/JSON). Caches the raw pull to data/raw/ before returning.
    """
    logger.info("Extracting file source: %s", url_or_path)
    if url_or_path.endswith(".json"):
        df = pd.read_json(url_or_path)
    else:
        df = pd.read_csv(url_or_path)

    out_path = _timestamped_path(prefix)
    df.to_csv(out_path, index=False)
    logger.info("Cached raw pull to %s (%d rows)", out_path, len(df))
    return df


def extract_from_api(
    endpoint: str,
    params: Optional[dict] = None,
    headers: Optional[dict] = None,
    max_retries: int = 3,
    backoff_seconds: float = 2.0,
    prefix: str = "api_raw",
) -> pd.DataFrame:
    """
    Extract data from a REST API endpoint with basic exponential backoff
    for rate-limit handling (Section 3.2).
    """
    attempt = 0
    while attempt < max_retries:
        response = requests.get(endpoint, params=params, headers=headers, timeout=30)
        if response.status_code == 200:
            payload = response.json()
            df = pd.json_normalize(payload)
            out_path = _timestamped_path(prefix)
            df.to_csv(out_path, index=False)
            logger.info("Cached API pull to %s (%d rows)", out_path, len(df))
            return df
        elif response.status_code == 429:
            wait = backoff_seconds * (2 ** attempt)
            logger.warning("Rate limited (429). Backing off for %.1fs", wait)
            time.sleep(wait)
            attempt += 1
        else:
            response.raise_for_status()
    raise RuntimeError(f"Failed to extract from {endpoint} after {max_retries} retries")


def extract_from_web_table(url: str, table_index: int = 0, prefix: str = "scraped") -> pd.DataFrame:
    """
    Fallback extraction for publicly available HTML tables.
    Used only when no API or bulk file export exists (Section 3.1).
    """
    tables = pd.read_html(url)
    df = tables[table_index]
    out_path = _timestamped_path(prefix)
    df.to_csv(out_path, index=False)
    logger.info("Cached scraped table to %s (%d rows)", out_path, len(df))
    return df


def extract_data(source_config: dict) -> pd.DataFrame:
    """
    Dispatch extraction based on a source configuration dict, e.g.:
        {"type": "file", "location": "https://.../data.csv"}
        {"type": "api", "endpoint": "https://.../v1/records", "params": {...}}
        {"type": "web_table", "url": "https://en.wikipedia.org/...", "table_index": 0}
    """
    source_type = source_config.get("type")
    if source_type == "file":
        return extract_from_file(source_config["location"])
    if source_type == "api":
        return extract_from_api(
            source_config["endpoint"],
            params=source_config.get("params"),
            headers=source_config.get("headers"),
        )
    if source_type == "web_table":
        return extract_from_web_table(
            source_config["url"], source_config.get("table_index", 0)
        )
    raise ValueError(f"Unknown source type: {source_type}")
